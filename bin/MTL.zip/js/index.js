app = {
	database : {},
	dateMask : 'yyyy-mm-dd HH:mm:ss',
	model : {
		selectedLocationVO : {},
		savedLocations : [],
		scannedLocations : [],
		images : [],
		weatherData : {},
		bbmRegistered : false
	}
};

