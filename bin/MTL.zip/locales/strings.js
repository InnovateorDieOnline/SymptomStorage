app.strings = {
	en : {
		title : 'My Travel Log',
		subTitle : 'Helping you capture your travel memories since 2013'
	},
	de : {
		title : 'Meine Notizbuch',
		subTitle : 'Wir helfen Ihnen, erfassen Sie Ihre Reiseerinnerungen seit 2013'
	},
	es : {
		title : 'Mi cuaderno',
		subTitle : 'Ayudar a capturar sus recuerdos de viaje desde 2013'
	},
	fr : {
		title : 'Carnet de voyage',
		subTitle : 'Pour vous aider à capturer vos souvenirs de voyage depuis 2013'
	}
};
